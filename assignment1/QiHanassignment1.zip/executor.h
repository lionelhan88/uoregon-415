/*
* Description: Project 1 header file. Contains function declarations for the command executor file 
*
* Author: Qi Han
*
* Date: 10/12/2019
*
*/

void commandExecutor(char *input);  /* command executor */